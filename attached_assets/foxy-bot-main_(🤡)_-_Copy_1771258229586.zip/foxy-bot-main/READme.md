<div align="center"> 
<strong>🦊 𝔽𝕆𝕏 𝔹𝕆𝕋</strong>
    <br>
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Orbitron&size=50&pause=1000&color=FF6600&center=true&width=910&height=100&lines=FOXBOT;Cunning+Bot;Made+By+Crafty+Fox" alt="Typing SVG" style="font-size: 50px;"/>
  </a> 
</div> 

<p align="center">
  <img style="width: 500px; height: 500px; border-radius: 20px; box-shadow: 0 0 30px #FF6600, 0 0 50px rgba(255, 102, 0, 0.3);" src="https://i.ibb.co/RG6dh6Cv/upload-1768151242802-a087ae11-jpg.jpg" alt="Fox Bot — Crafty Fox Aura" />
</p>

<div align="center">
  <h1 style="color: #FF6600; text-shadow: 0 0 10px #FF6600, 0 0 20px #FF6600;">
<br>
    <span style="font-size: 42px;">
      <b></b>
    </span>
    <i><sub>•By Crafty Fox •</sub></i>
  </h1>
</div>

<p align="center" style="color: #FF6600; text-shadow: 0 0 5px #FF6600;">
  <i>"As cunning as a fox, as swift as the wind"</i>
</p>


<div align="center">    
<strong> DEPLOY FOXBOT </strong>
    <br>
  <a href="https://your-deployment-link.com/">
    <img src="https://img.shields.io/badge/Deploy%20FOXBOT-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=8B4513&color=FF6600" alt="FORK REPO"/>
  </a>
</div>

<br>
<div align="center">
<strong> SESSION PAIR </strong>
    <br>
  <a href="https://your-pair-link.com/" target="_blank">
    <img src="https://img.shields.io/badge/pair %20code 1-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=8B4513&color=FF6600" alt="PAIR"/>
  </a>
</div>
<br>
<p align="center">  
<strong> DOWNLOAD ZIP </strong>
    <br>
    <a href="https://github.com/your-repo-link.git" target="_blank">
        <img alt="Download zip" src="https://img.shields.io/badge/DOWNLOAD%20 ZIP-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=8B4513&color=FF6600"/>
    </a>
</p>
<br>


<div align="center"> 
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Orbitron&size=50&pause=1000&color=FF6600&center=true&width=910&height=100&lines=FOXBOT;Forged+in+Cunning;Powered+by+Agility;Enhanced+by+Fox+Spirit" alt="Typing SVG" />
  </a> 
</div>